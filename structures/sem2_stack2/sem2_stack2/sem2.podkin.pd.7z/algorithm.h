
int algorithm();