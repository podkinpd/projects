#include "longnumber.h"
#include <iostream>

LongNumber::LongNumber() {
	buf = new digit_t[bufSize];
	for( size_t i = 0; i < bufSize; i++ ) {
		buf[i] = 0;
	}
	size = 0;
	size_t b = base;
	b--;
	while( b > 0 ) {
		b /= ten;
		lgBase++;
	}
	positive = true;
}

LongNumber::LongNumber( digit_t number ) {
	size_t b = base;
	b--;
	if( number > 0 ) {
		positive = true;
	}
	else {
		positive = false;
	}
	while( b > 0 ) {
		b /= ten;
		lgBase++;
	}
	buf = new digit_t[bufSize];
	size = 0;
	while( number > 0 ) {
		buf[size] = number % base;
		number /= base;
		size++;
	}
	for( size_t i = size; i < bufSize; i++ ) {
		buf[i] = 0;
	}
}

digit_t charToInt( char c ) {
	switch ( c ) {
	case '0' :
		return 0;
		break;
	case '1' :
		return 1;
		break;
	case '2' :
		return 2;
		break;
	case '3' :
		return 3;
		break;
	case '4' :
		return 4;
		break;
	case '5' :
		return 5;
		break;
	case '6' :
		return 6;
		break;
	case '7' :
		return 7;
		break;
	case '8' :
		return 8;
		break;
	case '9' :
		return 9;
		break;
	default:
		return 0;
	};
}

LongNumber::LongNumber( const char* ch ) {
	buf = new digit_t[bufSize];
	size_t numberOfCurrentCh = 0;
	if( ch[0] == '-' ) {
		positive = false;
		numberOfCurrentCh = 1;
	}
	else {
		positive = true;
	}

	size_t b = base;
	b--;
	while( b > 0 ) {
		b /= ten;
		lgBase++;
	}

	digit_t currentDigit;
	size_t length = 0;
	while( ch[length] != '\0' ) {
		length++;
	}
	if( !positive ) {
		length--;
	}
	size = ( length + 1 ) / lgBase;
	size_t first = length % lgBase;
	currentDigit = 0;
	for( size_t i = 0; i < first; i++ ) {
		currentDigit = currentDigit * 10 + charToInt( ch[numberOfCurrentCh] );
	}
	buf[size-1] = currentDigit;
	for( int i = size - 2; i >= 0; i-- ) {
		currentDigit = 0;
		for( size_t j = 0; j < lgBase; j++ ) {
			currentDigit = currentDigit * 10 + charToInt( ch[numberOfCurrentCh] );
		}
		buf[i] = currentDigit;
	}
	for( size_t i = size; i < bufSize; i++ ) {
		buf[i] = 0;
	}
}

LongNumber::LongNumber( const LongNumber& l ) {
	buf = new digit_t[bufSize];
	size = l.size;
	positive = l.positive;
	for( size_t i = 0; i < bufSize; i++ ) {
		buf[i] = l[i];;
	}
}

LongNumber::~LongNumber() {
	size = 0;
	delete [] buf;
	buf = nullptr;
}

digit_t& LongNumber::operator[]( const size_t index ) {
	return buf[index];
}

const digit_t LongNumber::operator[]( const size_t index ) const {
	return buf[index];
}

LongNumber& LongNumber::operator=( const LongNumber& l ) {
	if( this == &l ) {
		return *this;
	}
	size = l.size;
	positive = l.positive;
	for( size_t i = 0; i < size; i++ ) {
		buf[i] = l[i];
	}
	return *this;
}

bool LongNumber::isPositive() const {
	return positive;
}

void LongNumber::setSize( size_t index ) {
	size = index;
}

size_t LongNumber::getSize() const {
	return size;
}

size_t LongNumber::getBufSize() const {
	return bufSize;
}

size_t LongNumber::getBase() const {
	return base;
}

/*std::istream& operator>>( std::istream& in, const LongNumber& l ) {
	char c;
	size_t index = 0;
	char* ch = new char[l.getBufSize()];
	while( in >> c ) {
		ch[index] = c;
		index++;
	}
	LongNumber ll(

		
	return in;
}*/

std::ostream& operator<<( std::ostream& out, const LongNumber& l ) {
	if( !l.isPositive() ) {
		out << '-';
	}
	size_t size = l.getSize();
	for( size_t i = size - 1; i >= 0; i-- ) {
		out << l[i];
	}
	return out;
}

bool LongNumber::operator==( const LongNumber& l ) const {
	if( size != l.size ) {
		return false;
	}
	else {
		for( size_t i = 0; i < size; i++ ) {
			if( buf[i] != l[i] ) {
				return false;
			}
		}
		return true;
	}
}

bool LongNumber::operator<( const LongNumber& l ) const {
	if( size > l.size ) {
		return false;
	}
	else if( size < l.size ) {
		return true;
	}
	else {
		for( size_t i = 0; i < size; i++ ) {
			if( buf[i] > l[i] ) {
				return false;
			}
			else if( buf[i] < l[i] ) {
				return true;
			}
		}
		return false;
	}
}

bool LongNumber::operator>( const LongNumber& l ) const {
	if( size < l.size ) {
		return false;
	}
	else if( size > l.size ) {
		return true;
	}
	else {
		for( size_t i = 0; i < size; i++ ) {
			if( buf[i] < l[i] ) {
				return false;
			}
			else if( buf[i] > l[i] ) {
				return true;
			}
		}
		return false;
	}
}

LongNumber LongNumber::operator+( const digit_t number ) const {
	LongNumber l( number );
	return ( *this + l );
}

LongNumber LongNumber::operator+( const LongNumber& l ) const {
	if( ( positive && l.positive ) || ( !positive && !l.positive ) ) {
		LongNumber result( *this );
		for( size_t i = 0; i < l.size; i++ ) {
			result[i] += l[i];
			if( result[i] >= base ) {
				result[i+1]++;
				result[i] -= base;
			}
		}
		if( result.size < l.size ) {
			result.size = l.size;
		}
		if( result[result.size] > 0 ) {
			result.size++;
		}
		return result;
	}
	else {
		LongNumber result( *this );
		for( size_t i = 0; i < l.size; i++ ) {
			result[i] -= l[i];
			if( result[i] < 0 ) {
				result[i] += base;
				result[i+1]--;
			}
		}
		size_t i = l.size;
		while( result[i] < 0 ) {
			result[i] += base;
			i++;
			result[i]--;
		}
		while( result[result.size] == 0 ) {
			result.size--;
		}
		if( *this < l ) {
			result.positive = l.positive;
		}
		return result;
	}
}

LongNumber LongNumber::operator-( const digit_t number ) const {
	LongNumber l( number );
	if( l.positive == true ) {
		l.positive = false;
	}
	else {
		l.positive = true;
	}
	return ( *this + l );
}

LongNumber LongNumber::operator-( LongNumber& l ) const {
	if( l.positive == true ) {
		l.positive = false;
	}
	else {
		l.positive = true;
	}
	return ( *this + l );
}
