#pragma once
#include <iosfwd>

class istream;
class ostream;

typedef int digit_t;

class LongNumber {
private:
	static const size_t base = 10000;
	static const size_t bufSize = 10000;
	static const digit_t ten = 10;
	bool positive;
	size_t lgBase;
	digit_t* buf;
	size_t size;
public:
	LongNumber();
	LongNumber( digit_t );
	LongNumber( const char* );
	LongNumber( const LongNumber& );
	~LongNumber();

	digit_t& operator[]( const size_t );
	const digit_t operator[]( const size_t ) const;

	LongNumber& operator=( const LongNumber& l );

	bool isPositive() const;

	void setSize( size_t );

	size_t getSize() const;
	size_t getBufSize() const;
	size_t getBase() const;

	friend std::istream& operator>>( std::istream&, LongNumber& );
	friend std::ostream& operator<<( std::ostream&, LongNumber& );

	bool operator<( const LongNumber& ) const;
	bool operator>( const LongNumber& ) const;
	bool operator==( const LongNumber& ) const;

	LongNumber operator+( const digit_t ) const;
	LongNumber operator+( const LongNumber& ) const;

	LongNumber operator-( const digit_t ) const;
	LongNumber operator-( LongNumber& ) const;

};