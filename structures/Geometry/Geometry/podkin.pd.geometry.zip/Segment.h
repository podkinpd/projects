#pragma once
#include <cmath>
#include "Shape.h"
#include "Point.h"

class Point;

class Segment : public Shape {
protected:
	Point p1;
	Point p2;
public:
	Segment();
	Segment( const Point&, const Point& );
	Segment( const Segment& );

	Segment& operator=( const Segment& );

	bool operator==( const Segment& ) const;
	
	Point GetP1() const;
	Point GetP2() const;

	void SetP1( const Point& );
	void SetP2( const Point& );

	void Move( double, double );
	bool IsPointIn( const Point& ) const;
	Intersection F( const Segment& ) const;

	double DistanceToPoint( const Point& ) const;
	double ModuleToPoint( const Point& ) const;

};

Segment::Segment() : p1(), p2() {
}

Segment::Segment( const Point& a, const Point& b ) : p1(a), p2(b) {
}

Segment::Segment( const Segment& s ) : p1(s.p1), p2(s.p2) {
}

Segment& Segment::operator=( const Segment& s ) {
	p1 = s.p1;
	p2 = s.p2;
	return *this;
}

bool Segment::operator==( const Segment& s ) const {
	if( p1 == s.p1 && p2 == s.p2 ) {
		return true;
	}
	else {
		return false;
	}
}

Point Segment::GetP1() const {
	return p1;
}

Point Segment::GetP2() const {
	return p2;
}

void Segment::SetP1( const Point& p ) {
	p1 = p;
}

void Segment::SetP2( const Point& p ) {
	p2 = p;
}

void Segment::Move( double dx, double dy ) {
	p1.Move( dx, dy );
	p2.Move( dx, dy );
}

bool Segment::IsPointIn( const Point& p ) const {
	double eps = 0.00000001;
	if( this->DistanceToPoint( p ) == 0 ) {
		return true;
	}
	else {
		return false;
	}
}

Intersection Segment::F( const Segment& ) const {
	Intersection result;
	return result;
}

double Segment::DistanceToPoint( const Point& p ) const {
	double eps = 0.00000001;
	double d1 = Distance( p1, p ), d2 = Distance( p2, p ), d;
	double x1 = p1.GetX(), y1 = p1.GetY(), x2 = p2.GetX(), y2 = p2.GetY(), x = p.GetX(), y = p.GetY();
	d = p.ModulToStraight( y1 - y2, x2 - x1, x1 * y2 - x2 * y1 );
	if( d < eps ) {
		if( ( x <= x1 && x >= x2 ) || ( x <= x2 && x >= x1 ) ) {
			return 0;
		}
		else {
			return min( d1, d2 );
		}
	}
	else {
		return min( d1, min( d2, d ) );
	}
}

double Segment::ModuleToPoint( const Point& p ) const {
	return fabs( this->DistanceToPoint( p ) );
}