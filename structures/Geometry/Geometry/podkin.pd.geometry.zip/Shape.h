#pragma once
#include "CArray.h"

class Point;
class Segment;
class Intersection;

class Shape {
public:
	virtual void Move( double, double ) = 0;
	virtual bool IsPointIn( const Point& ) const = 0;
	virtual Intersection F( const Segment& ) const = 0; 

};

double min( double d1, double d2 ) {
	return ( d1 < d2 ) ? d1 : d2;
}

class Intersection {
private:
	bool isSegment;
	CArray<Point> buf;
public:
	Intersection();

	bool IsSegment() const;
	void SetIsSegment( const bool );

	CArray<Point> GetPoints() const;
	CArray<Point>& GetLinkToBuf();
};

Intersection::Intersection() : isSegment(false), buf() {
}

bool Intersection::IsSegment() const {
	return isSegment;
}

void Intersection::SetIsSegment( const bool b ) {
	isSegment = b;
}

CArray<Point> Intersection::GetPoints() const {
	return buf;
}

CArray<Point>& Intersection::GetLinkToBuf() {
	return buf;
}